// Variables para tratar individualmente con localStorage
var puesto1, puesto2, puesto3, puesto4, puesto5,
puesto6, puesto7, puesto8, puesto9, puesto10,
puesto11, puesto12, puesto13, puesto14, puesto15,
puesto16, puesto17, puesto18, puesto19, puesto20;

// Llamada ajax mediante POST al archivo demo2.php
function myAjax11() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio11'},success:function(html) {}});}
function myAjax12() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio12'},success:function(html) {}});}
function myAjax21() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio21'},success:function(html) {}});}
function myAjax22() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio22'},success:function(html) {}});}
function myAjax31() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio31'},success:function(html) {}});}
function myAjax32() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio32'},success:function(html) {}});}
function myAjax41() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio41'},success:function(html) {}});}
function myAjax42() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio42'},success:function(html) {}});}
function myAjax51() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio51'},success:function(html) {}});}
function myAjax52() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio52'},success:function(html) {}});}
function myAjax61() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio61'},success:function(html) {}});}
function myAjax62() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio62'},success:function(html) {}});}
function myAjax71() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio71'},success:function(html) {}});}
function myAjax72() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio72'},success:function(html) {}});}
function myAjax81() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio81'},success:function(html) {}});}
function myAjax82() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio82'},success:function(html) {}});}
function myAjax91() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio91'},success:function(html) {}});}
function myAjax92() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio92'},success:function(html) {}});}
function myAjax101() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio101'},success:function(html) {}});}
function myAjax102() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio102'},success:function(html) {}});}
function myAjax111() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio111'},success:function(html) {}});}
function myAjax112() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio112'},success:function(html) {}});}
function myAjax121() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio121'},success:function(html) {}});}
function myAjax122() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio122'},success:function(html) {}});}
function myAjax131() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio131'},success:function(html) {}});}
function myAjax132() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio132'},success:function(html) {}});}
function myAjax141() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio141'},success:function(html) {}});}
function myAjax142() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio142'},success:function(html) {}});}
function myAjax151() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio151'},success:function(html) {}});}
function myAjax152() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio152'},success:function(html) {}});}
function myAjax161() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio161'},success:function(html) {}});}
function myAjax162() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio162'},success:function(html) {}});}
function myAjax171() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio171'},success:function(html) {}});}
function myAjax172() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio172'},success:function(html) {}});}
function myAjax181() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio181'},success:function(html) {}});}
function myAjax182() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio182'},success:function(html) {}});}
function myAjax191() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio191'},success:function(html) {}});}
function myAjax192() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio192'},success:function(html) {}});}
function myAjax201() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio201'},success:function(html) {}});}
function myAjax202() {$.ajax({type: "POST",url: 'js/demo2.php',data:{action:'cambio202'},success:function(html) {}});}



// Identifica el botón pulsado y guarda el estado en el array de puestos. Si ya está reservado, lo libera y viceversa
function reply_click(clicked_id){

console.log("Da "+localStorage.sitio1);

    // Switch case, similar a sucesión de "ifs" para verificar el puesto pulsado
	switch (clicked_id) {
    case "pos1":
        // Si está libre
        if((localStorage.puesto1 != 1) && (localStorage.sitio1 == 0)){
            alert("Puesto 1 reservado");
            localStorage.puesto1 = 1;
            myAjax11();
            break;
        }
        // Si está ocupado
        if((localStorage.puesto1 != 0) && (localStorage.sitio1 == 1)){
            alert("Puesto 1 liberado");
            localStorage.puesto1 = 0;
            myAjax12();
            break;
        }
    case "pos2":
        if((localStorage.puesto2 != 1) && (localStorage.sitio2 == 0)){
            alert("Puesto 2 reservado");
            localStorage.puesto2 = 1;
            myAjax21();
            break;
        }
        if((localStorage.puesto2 != 0) && (localStorage.sitio2 == 1)){
            alert("Puesto 2 liberado");
            localStorage.puesto2 = 0;
            myAjax22();
            break;
        }
    case "pos3":
        if((localStorage.puesto3 != 1) && (localStorage.sitio3 == 0)){
            alert("Puesto 3 reservado");
            localStorage.puesto3 = 1;
            myAjax31();
            break;
        }
        if((localStorage.puesto3 != 0) && (localStorage.sitio3 == 1)){
            alert("Puesto 3 liberado");
            localStorage.puesto3 = 0;
            myAjax32();
            break;
        }
    case "pos4":
        if((localStorage.puesto4 != 1) && (localStorage.sitio4 == 0)){
            alert("Puesto 4 reservado");
            localStorage.puesto4 = 1;
            myAjax41();
            break;
        }
        if((localStorage.puesto4 != 0) && (localStorage.sitio4 == 1)){
            alert("Puesto 4 liberado");
            localStorage.puesto4 = 0;
            myAjax42();
            break;
        }
    case "pos5":
        if((localStorage.puesto5 != 1) && (localStorage.sitio5 == 0)){
            alert("Puesto 5 reservado");
            localStorage.puesto5 = 1;
            myAjax51();
            break;
        }
        if((localStorage.puesto5 != 0) && (localStorage.sitio5 == 1)){
            alert("Puesto 5 liberado");
            localStorage.puesto5 = 0;
            myAjax52();
            break;
        }
    case "pos6":
        if((localStorage.puesto6 != 1) && (localStorage.sitio6 == 0)){
            alert("Puesto 6 reservado");
            localStorage.puesto6 = 1;
            myAjax61();
            break;
        }
        if((localStorage.puesto6 != 0) && (localStorage.sitio6 == 1)){
            alert("Puesto 6 liberado");
            localStorage.puesto6 = 0;
            myAjax62();
            break;
        }
    case "pos7":
        if((localStorage.puesto7 != 1) && (localStorage.sitio7 == 0)){
            alert("Puesto 7 reservado");
            localStorage.puesto7 = 1;
            myAjax71();
            break;
        }
        if((localStorage.puesto7 != 0) && (localStorage.sitio7 == 1)){
            alert("Puesto 7 liberado");
            localStorage.puesto7 = 0;
            myAjax72();
            break;
        }
    case "pos8":
        if((localStorage.puesto8 != 1) && (localStorage.sitio8 == 0)){
            alert("Puesto 8 reservado");
            localStorage.puesto8 = 1;
            myAjax81();
            break;
        }
        if((localStorage.puesto8 != 0) && (localStorage.sitio8 == 1)){
            alert("Puesto 8 liberado");
            localStorage.puesto8 = 0;
            myAjax82();
            break;
        }
    case "pos9":
        if((localStorage.puesto9 != 1) && (localStorage.sitio9 == 0)){
            alert("Puesto 9 reservado");
            localStorage.puesto9 = 1;
            myAjax91();
            break;
        }
        if((localStorage.puesto9 != 0) && (localStorage.sitio9 == 1)){
            alert("Puesto 9 liberado");
            localStorage.puesto9 = 0;
            myAjax92();
            break;
        }
    case "pos10":
        if((localStorage.puesto10 != 1) && (localStorage.sitio10 == 0)){
            alert("Puesto 10 reservado");
            localStorage.puesto10 = 1;
            myAjax101();
            break;
        }
        if((localStorage.puesto10 != 0) && (localStorage.sitio10 == 1)){
            alert("Puesto 10 liberado");
            localStorage.puesto10 = 0;
            myAjax102();
            break;
        }
    case "pos11":
        if((localStorage.puesto11 != 1) && (localStorage.sitio11 == 0)){
            alert("Puesto 11 reservado");
            localStorage.puesto11 = 1;
            myAjax111();
            break;
        }
        if((localStorage.puesto11 != 0) && (localStorage.sitio11 == 1)){
            alert("Puesto 11 liberado");
            localStorage.puesto11 = 0;
            myAjax112();
            break;
        }
    case "pos12":
        if((localStorage.puesto12 != 1) && (localStorage.sitio12 == 0)){
            alert("Puesto 12 reservado");
            localStorage.puesto12 = 1;
            myAjax121();
            break;
        }
        if((localStorage.puesto12 != 0) && (localStorage.sitio12 == 1)){
            alert("Puesto 12 liberado");
            localStorage.puesto12 = 0;
            myAjax122();
            break;
        }
    case "pos13":
        if((localStorage.puesto13 != 1) && (localStorage.sitio13 == 0)){
            alert("Puesto 13 reservado");
            localStorage.puesto13 = 1;
            myAjax131();
            break;
        }
        if((localStorage.puesto13 != 0) && (localStorage.sitio13 == 1)){
            alert("Puesto 13 liberado");
            localStorage.puesto13 = 0;
            myAjax132();
            break;
        }
    case "pos14":
        if((localStorage.puesto14 != 1) && (localStorage.sitio14 == 0)){
            alert("Puesto 14 reservado");
            localStorage.puesto14 = 1;
            myAjax141();
            break;
        }
        if((localStorage.puesto14 != 0) && (localStorage.sitio14 == 1)){
            alert("Puesto 14 liberado");
            localStorage.puesto14 = 0;
            myAjax142();
            break;
        }
    case "pos15":
        if((localStorage.puesto15 != 1) && (localStorage.sitio15 == 0)){
            alert("Puesto 15 reservado");
            localStorage.puesto15 = 1;
            myAjax151();
            break;
        }
        if((localStorage.puesto15 != 0) && (localStorage.sitio15 == 1)){
            alert("Puesto 15 liberado");
            localStorage.puesto15 = 0;
            myAjax152();
            break;
        }
    case "pos16":
        if((localStorage.puesto16 != 1) && (localStorage.sitio16 == 0)){
            alert("Puesto 16 reservado");
            localStorage.puesto16 = 1;
            myAjax161();
            break;
        }
        if((localStorage.puesto16 != 0) && (localStorage.sitio16 == 1)){
            alert("Puesto 16 liberado");
            localStorage.puesto16 = 0;
            myAjax162();
            break;
        }
    case "pos17":
        if((localStorage.puesto17 != 1) && (localStorage.sitio17 == 0)){
            alert("Puesto 17 reservado");
            localStorage.puesto17 = 1;
            myAjax171();
            break;
        }
        if((localStorage.puesto17 != 0) && (localStorage.sitio17 == 1)){
            alert("Puesto 17 liberado");
            localStorage.puesto17 = 0;
            myAjax172();
            break;
        }
    case "pos18":
        if((localStorage.puesto18 != 1) && (localStorage.sitio18 == 0)){
            alert("Puesto 18 reservado");
            localStorage.puesto18 = 1;
            myAjax181();
            break;
        }
        if((localStorage.puesto18 != 0) && (localStorage.sitio18 == 1)){
            alert("Puesto 18 liberado");
            localStorage.puesto18 = 0;
            myAjax182();
            break;
        }
    case "pos19":
        if((localStorage.puesto19 != 1) && (localStorage.sitio19 == 0)){
            alert("Puesto 19 reservado");
            localStorage.puesto19 = 1;
            myAjax191();
            break;
        }
        if((localStorage.puesto19 != 0) && (localStorage.sitio19 == 1)){
            alert("Puesto 19 liberado");
            localStorage.puesto19 = 0;
            myAjax192();
            break;
        }
    case "pos20":
        if((localStorage.puesto20 != 1) && (localStorage.sitio20 == 0)){
            alert("Puesto 20 reservado");
            localStorage.puesto20 = 1;
            myAjax201();
            break;
        }
        if((localStorage.puesto20 != 0) && (localStorage.sitio20 == 1)){
            alert("Puesto 20 liberado");
            localStorage.puesto20 = 0;
            myAjax202();
            break;
        }
    default:
        console.log("nada");
	}
}