// Variable que guarda la imagen de los marcadores
var image = 'js/bici.png';

// Función que inicializa el mapa para sedeprincipal.html
function initMapPrincipal() {

  // Latitud y longitud del punto central del mapa mostrado
  var myLatLng = {lat: 4.637815, lng: -74.063900};

  // Inicializa el mapa, lo centra y establece el zoom. Lo relaciona con el id donde será mostrado
  var map = new google.maps.Map(document.getElementById('mapid'), {
    zoom: 17,
    center: myLatLng
  });

  // Inicializa un marcador, que se presenta en el mismo punto central con una animación de entrada y el icono de "image" antes declarado
  var marker = new google.maps.Marker({
    position: myLatLng,
    animation: google.maps.Animation.DROP,
    map: map,
    icon: image
  });

  // Popup
  var infowindow = new google.maps.InfoWindow({
  content:"Sede Principal"
  });

// Muestra el popup al pasar el puntero por encima
google.maps.event.addListener(marker, 'mouseover', function() {
  infowindow.open(map,marker);
  });
google.maps.event.addListener(marker, 'mouseout', function() {
  infowindow.close();
  });

// Muestra la pagina de la sede principal al pulsar
  marker.addListener('click', function() {
    window.open ('estadosedeprincipal.html','_self',false);
  });
}


// Función que inicializa el mapa para angelico.html
function initMapAngelico() {

  // Latitud y longitud del punto central del mapa mostrado
  var myLatLng = {lat: 4.656584, lng: -74.056297};

  // Inicializa el mapa, lo centra y establece el zoom. Lo relaciona con el id donde será mostrado
  var map = new google.maps.Map(document.getElementById('mapid2'), {
    zoom: 17,
    center: myLatLng
  });

  // Inicializa un marcador, que se presenta en el mismo punto central con una animación de entrada y el icono de "image" antes declarado
  var marker = new google.maps.Marker({
    position: myLatLng,
    map: map,
    animation: google.maps.Animation.DROP,
    map: map,
    icon: image
  });

  // Popup
  var infowindow = new google.maps.InfoWindow({
  content:"Doctor Angélico Santo Tomás"
  });

// Muestra el popup al pasar el puntero por encima
google.maps.event.addListener(marker, 'mouseover', function() {
  infowindow.open(map,marker);
  });

google.maps.event.addListener(marker, 'mouseout', function() {
  infowindow.close();
  });

// Muestra la pagina de angelico al pulsar
  marker.addListener('click', function() {
    window.open ('estadoangelico.html','_self',false);
  });
}

// Función que inicializa el mapa para sedes.html 
function initMapGlobal() {

  // Latitud y longitud del punto central del mapa mostrado
  var myLatLng = {lat: 4.637827, lng: -74.063806};

  // Inicializa el mapa, lo centra y establece el zoom. Lo relaciona con el id donde será mostrado
  var map = new google.maps.Map(document.getElementById('mapid3'), {
    zoom: 14,
    center: myLatLng
  });

  // Inicializa un marcador, que se presenta en el punto correspondiente al edificio Angelico con una animación de entrada y el icono de "image" antes declarado
  var marker = new google.maps.Marker({
    position: {lat: 4.656584, lng: -74.056297},
    map: map,
    animation: google.maps.Animation.DROP,
    map: map,
    icon: image
  });

  // Popup
  var infowindow = new google.maps.InfoWindow({
    content:"Edificio Angelico Santo Tomás"
  });

// Muestra el popup al pasar el puntero por encima
google.maps.event.addListener(marker, 'mouseover', function() {
  infowindow.open(map,marker);
  });

google.maps.event.addListener(marker, 'mouseout', function() {
  infowindow.close();
  });

// Muestra la pagina de angelico al pulsar
  marker.addListener('click', function() {
    window.open ('estadoangelico.html','_self',false);
  });

  // Inicializa un marcador, que se presenta en el punto correspondiente a la sede principal con una animación de entrada y el icono de "image" antes declarado
  var marker2 = new google.maps.Marker({
    position: {lat: 4.638318, lng: -74.064424},
    map: map,
    animation: google.maps.Animation.DROP,
    map: map,
    icon: image
  });

  // Popup
  var infowindow2 = new google.maps.InfoWindow({
    content:"Sede principal Santo Tomás"
  });

// Muestra el popup al pasar el puntero por encima
google.maps.event.addListener(marker2, 'mouseover', function() {
  infowindow2.open(map,marker2);
  });

google.maps.event.addListener(marker2, 'mouseout', function() {
  infowindow2.close();
  });

// Muestra la pagina de la sede principal al pulsar
marker2.addListener('click', function() {
  window.open ('estadosedeprincipal.html','_self',false);
  });
}