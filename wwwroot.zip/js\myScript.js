var onlyBikes = [];
var dna = 15;
// Variables con los estados de cada puesto, ordenados del puesto 1 al 20
var sitio1, sitio2, sitio3, sitio4, sitio5,
sitio6, sitio7, sitio8, sitio9, sitio10,
sitio11, sitio12, sitio13, sitio14, sitio15,
sitio16, sitio17, sitio18, sitio19, sitio20;

var muestra = [];
var contador = 0;

// Refresca cada segundo
var myVar = setInterval(init, 500);
function loadJSON(callback) {

// Lee el json del servidor
	var obj = new XMLHttpRequest();
	obj.overrideMimeType("application/json");
	obj.open("GET","http://parkurbike.azurewebsites.net/js/test2.json", true);
	obj.onreadystatechange = function () {
	if (obj.readyState == 4 && obj.status == "200") {
		if (callback){callback(obj.responseText);}
		}
	};

	obj.send(null);
}
//var actual_JSON;
function init() {
				loadJSON(function(response) {
						//Parse JSON into object
						actual_JSON = JSON.parse(response);
						//display on console
						//for (i = 0; i < actual_JSON[0].puestos.length; i++) {
						//	console.log("Puesto "+actual_JSON[0].puestos[i].id +": "+ actual_JSON[0].puestos[i].status);
						//}
				
						//display on html
						for (i = 0; i < actual_JSON[0].puestos.length; i++) 
						{
							onlyBikes[i] = actual_JSON[0].puestos[i].status;
						}

		// Guarda el estado del json en local Storage
		localStorage.sitio1 = onlyBikes[0];
		localStorage.sitio2 = onlyBikes[1];
		localStorage.sitio3 = onlyBikes[2];
		localStorage.sitio4 = onlyBikes[3];
		localStorage.sitio5 = onlyBikes[4];
		localStorage.sitio6 = onlyBikes[5];
		localStorage.sitio7 = onlyBikes[6];
		localStorage.sitio8 = onlyBikes[7];
		localStorage.sitio9 = onlyBikes[8];
		localStorage.sitio10 = onlyBikes[9];
		localStorage.sitio11 = onlyBikes[10];
		localStorage.sitio12 = onlyBikes[11];
		localStorage.sitio13 = onlyBikes[12];
		localStorage.sitio14 = onlyBikes[13];
		localStorage.sitio15 = onlyBikes[14];
		localStorage.sitio16 = onlyBikes[15];
		localStorage.sitio17 = onlyBikes[16];
		localStorage.sitio18 = onlyBikes[17];
		localStorage.sitio19 = onlyBikes[18];
		localStorage.sitio20 = onlyBikes[19];
		
		console.log("working: " + onlyBikes[1] + " siguiente " + onlyBikes[2]);

		//localStorage.puesto1 = localStorage.sitio1;
		
		for (contador = 0; contador < onlyBikes.length; contador++)
		{
			if (onlyBikes[contador] == 1)
			{
				onlyBikes[contador] =  "  <img src='manual/images/Bocu.png' width='150' heigth='150' />     ";
				//onlyBikes[contador] =  [contador +1]  + "  <img src='manual/images/Bocu.png' width='150' heigth='150' />     ";
			}                        //<img src="{{img}}" width="180" height="50" alt="{{titulo}}"/>
			else if (onlyBikes[contador] == 0)
			{
				onlyBikes[contador] =  "   <img src='manual/images/biciverde.png' width='150' heigth='2000' />     ";
			}
		}
		var out = document.getElementById("demo"); //
		//out.style.fontSize = "10000 px";
		out.innerHTML = onlyBikes;
		
		//out.innerHTML=localStorage.sitio1;
		
		
		
		document.getElementById("contenido").innerHTML= localStorage.puesto1+","+localStorage.puesto2+","+localStorage.puesto3+","+localStorage.puesto4+","+
		localStorage.puesto5+","+localStorage.puesto6+","+localStorage.puesto7+","+localStorage.puesto8+","+localStorage.puesto9+","+localStorage.puesto10+","+
		localStorage.puesto11+","+localStorage.puesto12+","+localStorage.puesto13+","+localStorage.puesto14+","+localStorage.puesto15+","+localStorage.puesto16
		+","+localStorage.puesto17+","+localStorage.puesto18+","+localStorage.puesto19+","+localStorage.puesto20;
		
	});
	
}

