<?php
	
		
// Redirige la llamada POST a las funciones abajo escritas
if($_POST['action'] == 'cambio11') {changejson11();}
if($_POST['action'] == 'cambio12') {changejson12();}
if($_POST['action'] == 'cambio21') {changejson21();}
if($_POST['action'] == 'cambio22') {changejson22();}
if($_POST['action'] == 'cambio31') {changejson31();}
if($_POST['action'] == 'cambio32') {changejson32();}
if($_POST['action'] == 'cambio41') {changejson41();}
if($_POST['action'] == 'cambio42') {changejson42();}
if($_POST['action'] == 'cambio51') {changejson51();}
if($_POST['action'] == 'cambio52') {changejson52();}
if($_POST['action'] == 'cambio61') {changejson61();}
if($_POST['action'] == 'cambio62') {changejson62();}
if($_POST['action'] == 'cambio71') {changejson71();}
if($_POST['action'] == 'cambio72') {changejson72();}
if($_POST['action'] == 'cambio81') {changejson81();}
if($_POST['action'] == 'cambio82') {changejson82();}
if($_POST['action'] == 'cambio91') {changejson91();}
if($_POST['action'] == 'cambio92') {changejson92();}
if($_POST['action'] == 'cambio101') {changejson101();}
if($_POST['action'] == 'cambio102') {changejson102();}
if($_POST['action'] == 'cambio111') {changejson111();}
if($_POST['action'] == 'cambio112') {changejson112();}
if($_POST['action'] == 'cambio121') {changejson121();}
if($_POST['action'] == 'cambio122') {changejson122();}
if($_POST['action'] == 'cambio131') {changejson131();}
if($_POST['action'] == 'cambio132') {changejson132();}
if($_POST['action'] == 'cambio141') {changejson141();}
if($_POST['action'] == 'cambio142') {changejson142();}
if($_POST['action'] == 'cambio151') {changejson151();}
if($_POST['action'] == 'cambio152') {changejson152();}
if($_POST['action'] == 'cambio161') {changejson161();}
if($_POST['action'] == 'cambio162') {changejson162();}
if($_POST['action'] == 'cambio171') {changejson171();}
if($_POST['action'] == 'cambio172') {changejson172();}
if($_POST['action'] == 'cambio181') {changejson181();}
if($_POST['action'] == 'cambio182') {changejson182();}
if($_POST['action'] == 'cambio191') {changejson191();}
if($_POST['action'] == 'cambio192') {changejson192();}
if($_POST['action'] == 'cambio201') {changejson201();}
if($_POST['action'] == 'cambio202') {changejson202();}

//Si a llegado hasta aquí, es que el puesto estaba vacío, y ahora se va a ocupar.
//Cambia la línea del json por la correcta con el puesto reservado, y sobreescribe el archivo.
function changejson11(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 1,"status": 0','        "id": 1,"status": 1',$str);
fwrite($fp,$str,strlen($str));}

function changejson12(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 1,"status": 1','        "id": 1,"status": 0',$str);
fwrite($fp,$str,strlen($str));}

function changejson21(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 2,"status": 0','        "id": 2,"status": 1',$str);
fwrite($fp,$str,strlen($str));}

function changejson22(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 2,"status": 1','        "id": 2,"status": 0',$str);
fwrite($fp,$str,strlen($str));}

function changejson31(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 3,"status": 0','        "id": 3,"status": 1',$str);
fwrite($fp,$str,strlen($str));}

function changejson32(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 3,"status": 1','        "id": 3,"status": 0',$str);
fwrite($fp,$str,strlen($str));}

function changejson41(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 4,"status": 0','        "id": 4,"status": 1',$str);
fwrite($fp,$str,strlen($str));}

function changejson42(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 4,"status": 1','        "id": 4,"status": 0',$str);
fwrite($fp,$str,strlen($str));}

function changejson51(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 5,"status": 0','        "id": 5,"status": 1',$str);
fwrite($fp,$str,strlen($str));}

function changejson52(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 5,"status": 1','        "id": 5,"status": 0',$str);
fwrite($fp,$str,strlen($str));}

function changejson61(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 6,"status": 0','        "id": 6,"status": 1',$str);
fwrite($fp,$str,strlen($str));}

function changejson62(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 6,"status": 1','        "id": 6,"status": 0',$str);
fwrite($fp,$str,strlen($str));}

function changejson71(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 7,"status": 0','        "id": 7,"status": 1',$str);
fwrite($fp,$str,strlen($str));}

function changejson72(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 7,"status": 1','        "id": 7,"status": 0',$str);
fwrite($fp,$str,strlen($str));}

function changejson81(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 8,"status": 0','        "id": 8,"status": 1',$str);
fwrite($fp,$str,strlen($str));}

function changejson82(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 8,"status": 1','        "id": 8,"status": 0',$str);
fwrite($fp,$str,strlen($str));}

function changejson91(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 9,"status": 0','        "id": 9,"status": 1',$str);
fwrite($fp,$str,strlen($str));}

function changejson92(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 9,"status": 1','        "id": 9,"status": 0',$str);
fwrite($fp,$str,strlen($str));}

function changejson101(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 10,"status": 0','        "id": 10,"status": 1',$str);
fwrite($fp,$str,strlen($str));}

function changejson102(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 10,"status": 1','        "id": 10,"status": 0',$str);
fwrite($fp,$str,strlen($str));}

function changejson111(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 11,"status": 0','        "id": 11,"status": 1',$str);
fwrite($fp,$str,strlen($str));}

function changejson112(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 11,"status": 1','        "id": 11,"status": 0',$str);
fwrite($fp,$str,strlen($str));}

function changejson121(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 12,"status": 0','        "id": 12,"status": 1',$str);
fwrite($fp,$str,strlen($str));}

function changejson122(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 12,"status": 1','        "id": 12,"status": 0',$str);
fwrite($fp,$str,strlen($str));}

function changejson131(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 13,"status": 0','        "id": 13,"status": 1',$str);
fwrite($fp,$str,strlen($str));}

function changejson132(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 13,"status": 1','        "id": 13,"status": 0',$str);
fwrite($fp,$str,strlen($str));}

function changejson141(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 14,"status": 0','        "id": 14,"status": 1',$str);
fwrite($fp,$str,strlen($str));}

function changejson142(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 14,"status": 1','        "id": 14,"status": 0',$str);
fwrite($fp,$str,strlen($str));}

function changejson151(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 15,"status": 0','        "id": 15,"status": 1',$str);
fwrite($fp,$str,strlen($str));}

function changejson152(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 15,"status": 1','        "id": 15,"status": 0',$str);
fwrite($fp,$str,strlen($str));}

function changejson161(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 16,"status": 0','        "id": 16,"status": 1',$str);
fwrite($fp,$str,strlen($str));}

function changejson162(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 16,"status": 1','        "id": 16,"status": 0',$str);
fwrite($fp,$str,strlen($str));}

function changejson171(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 17,"status": 0','        "id": 17,"status": 1',$str);
fwrite($fp,$str,strlen($str));}

function changejson172(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 17,"status": 1','        "id": 17,"status": 0',$str);
fwrite($fp,$str,strlen($str));}

function changejson181(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 18,"status": 0','        "id": 18,"status": 1',$str);
fwrite($fp,$str,strlen($str));}

function changejson182(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 18,"status": 1','        "id": 18,"status": 0',$str);
fwrite($fp,$str,strlen($str));}

function changejson191(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 19,"status": 0','        "id": 19,"status": 1',$str);
fwrite($fp,$str,strlen($str));}

function changejson192(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 19,"status": 1','        "id": 19,"status": 0',$str);
fwrite($fp,$str,strlen($str));}

function changejson201(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 20,"status": 0','        "id": 20,"status": 1',$str);
fwrite($fp,$str,strlen($str));}

function changejson202(){
$str=implode("",file('test2.json'));
$fp=fopen('test2.json','w');
$str=str_replace('        "id": 20,"status": 1','        "id": 20,"status": 0',$str);
fwrite($fp,$str,strlen($str));}

?>