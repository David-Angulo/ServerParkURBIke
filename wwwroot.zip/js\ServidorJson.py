#!/usr/bin/env python

import socket
import sys
import json
from thread import *
 
HOST = '40.124.12.75'   # Symbolic name meaning all available interfaces
PORT = 5005 # Arbitrary non-privileged port
 
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print 'Socket created'
 
#Bind socket to local host and port
try:
    s.bind((HOST, PORT))
except socket.error as msg:
    print 'Bind failed. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
    sys.exit()
     
print 'Socket bind complete'
 
#Start listening on socket
s.listen(10)
print 'Socket now listening'
 
#Function for handling connections. This will be used to create threads
def clientthread(conn):
    #Sending message to connected client
    conn.send('Conect') #send only takes string
     
    #infinite loop so that function do not terminate and thread do not end.
    while 1:
       #Receiving from client
        data = conn.recv(1024)
        reply = 'OK...' + data
        if not data: 
            break
        print (reply)
        conn.sendall (reply)
        outfile = open('test2.json', 'w') 
        outfile.write(data)
        outfile.close()
        outfile = open('test3.txt', 'a') 
        outfile.write(data)
        outfile.close()
    #came out of loop
    conn.close()


#now keep talking with the client
while 1:
    #wait to accept a connection - blocking call
    conn, addr = s.accept()
    print 'Connected with ' + addr[0] + ':' + str(addr[1])
    #start new thread takes 1st argument as a function name to be run, second is the tuple of arguments to the function.
    start_new_thread(clientthread ,(conn,))
 
s.close()